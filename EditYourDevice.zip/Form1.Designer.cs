﻿namespace EditYourDevice
{
    partial class Form1
    {
        /// <summary>
        /// Обязательная переменная конструктора.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Освободить все используемые ресурсы.
        /// </summary>
        /// <param name="disposing">истинно, если управляемый ресурс должен быть удален; иначе ложно.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Код, автоматически созданный конструктором форм Windows

        /// <summary>
        /// Требуемый метод для поддержки конструктора — не изменяйте 
        /// содержимое этого метода с помощью редактора кода.
        /// </summary>
        private void InitializeComponent()
        {
            this.components = new System.ComponentModel.Container();
            this.label1 = new System.Windows.Forms.Label();
            this.guna2BorderlessForm1 = new Guna.UI2.WinForms.Guna2BorderlessForm(this.components);
            this.label2 = new System.Windows.Forms.Label();
            this.ProcessorName = new Guna.UI2.WinForms.Guna2TextBox();
            this.guna2PictureBox1 = new Guna.UI2.WinForms.Guna2PictureBox();
            this.VideocardName = new Guna.UI2.WinForms.Guna2TextBox();
            this.label3 = new System.Windows.Forms.Label();
            this.RAM = new Guna.UI2.WinForms.Guna2TextBox();
            this.ProcessorSpeed = new Guna.UI2.WinForms.Guna2TextBox();
            this.label4 = new System.Windows.Forms.Label();
            this.guna2Button1 = new Guna.UI2.WinForms.Guna2Button();
            ((System.ComponentModel.ISupportInitialize)(this.guna2PictureBox1)).BeginInit();
            this.SuspendLayout();
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Font = new System.Drawing.Font("Kreadon Demi", 15.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.label1.Location = new System.Drawing.Point(54, 12);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(154, 23);
            this.label1.TabIndex = 0;
            this.label1.Text = "EditYourDevice";
            // 
            // guna2BorderlessForm1
            // 
            this.guna2BorderlessForm1.AnimateWindow = true;
            this.guna2BorderlessForm1.BorderRadius = 6;
            this.guna2BorderlessForm1.ContainerControl = this;
            this.guna2BorderlessForm1.DockIndicatorTransparencyValue = 1D;
            this.guna2BorderlessForm1.DragStartTransparencyValue = 1D;
            this.guna2BorderlessForm1.ShadowColor = System.Drawing.Color.White;
            this.guna2BorderlessForm1.TransparentWhileDrag = true;
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Font = new System.Drawing.Font("Kreadon Demi", 15.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.label2.Location = new System.Drawing.Point(14, 50);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(164, 23);
            this.label2.TabIndex = 1;
            this.label2.Text = "Processor Name";
            // 
            // ProcessorName
            // 
            this.ProcessorName.Animated = true;
            this.ProcessorName.Cursor = System.Windows.Forms.Cursors.IBeam;
            this.ProcessorName.DefaultText = "";
            this.ProcessorName.DisabledState.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(208)))), ((int)(((byte)(208)))), ((int)(((byte)(208)))));
            this.ProcessorName.DisabledState.FillColor = System.Drawing.Color.FromArgb(((int)(((byte)(226)))), ((int)(((byte)(226)))), ((int)(((byte)(226)))));
            this.ProcessorName.DisabledState.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(138)))), ((int)(((byte)(138)))), ((int)(((byte)(138)))));
            this.ProcessorName.DisabledState.PlaceholderForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(138)))), ((int)(((byte)(138)))), ((int)(((byte)(138)))));
            this.ProcessorName.FocusedState.BorderColor = System.Drawing.Color.Teal;
            this.ProcessorName.Font = new System.Drawing.Font("Kreadon Demi", 15.75F, System.Drawing.FontStyle.Bold);
            this.ProcessorName.ForeColor = System.Drawing.Color.Black;
            this.ProcessorName.HoverState.BorderColor = System.Drawing.Color.Teal;
            this.ProcessorName.Location = new System.Drawing.Point(184, 39);
            this.ProcessorName.Margin = new System.Windows.Forms.Padding(5, 5, 5, 5);
            this.ProcessorName.Name = "ProcessorName";
            this.ProcessorName.PlaceholderForeColor = System.Drawing.Color.DarkCyan;
            this.ProcessorName.PlaceholderText = "";
            this.ProcessorName.SelectedText = "";
            this.ProcessorName.Size = new System.Drawing.Size(253, 34);
            this.ProcessorName.Style = Guna.UI2.WinForms.Enums.TextBoxStyle.Material;
            this.ProcessorName.TabIndex = 2;
            // 
            // guna2PictureBox1
            // 
            this.guna2PictureBox1.Image = global::EditYourDevice.Properties.Resources.icons8_github_500;
            this.guna2PictureBox1.ImageRotate = 0F;
            this.guna2PictureBox1.Location = new System.Drawing.Point(12, 7);
            this.guna2PictureBox1.Name = "guna2PictureBox1";
            this.guna2PictureBox1.Size = new System.Drawing.Size(33, 31);
            this.guna2PictureBox1.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.guna2PictureBox1.TabIndex = 3;
            this.guna2PictureBox1.TabStop = false;
            this.guna2PictureBox1.Click += new System.EventHandler(this.guna2PictureBox1_Click);
            // 
            // VideocardName
            // 
            this.VideocardName.Animated = true;
            this.VideocardName.Cursor = System.Windows.Forms.Cursors.IBeam;
            this.VideocardName.DefaultText = "";
            this.VideocardName.DisabledState.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(208)))), ((int)(((byte)(208)))), ((int)(((byte)(208)))));
            this.VideocardName.DisabledState.FillColor = System.Drawing.Color.FromArgb(((int)(((byte)(226)))), ((int)(((byte)(226)))), ((int)(((byte)(226)))));
            this.VideocardName.DisabledState.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(138)))), ((int)(((byte)(138)))), ((int)(((byte)(138)))));
            this.VideocardName.DisabledState.PlaceholderForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(138)))), ((int)(((byte)(138)))), ((int)(((byte)(138)))));
            this.VideocardName.FocusedState.BorderColor = System.Drawing.Color.Teal;
            this.VideocardName.Font = new System.Drawing.Font("Kreadon Demi", 15.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.VideocardName.ForeColor = System.Drawing.Color.Black;
            this.VideocardName.HoverState.BorderColor = System.Drawing.Color.Teal;
            this.VideocardName.Location = new System.Drawing.Point(184, 80);
            this.VideocardName.Margin = new System.Windows.Forms.Padding(5, 5, 5, 5);
            this.VideocardName.Name = "VideocardName";
            this.VideocardName.PlaceholderForeColor = System.Drawing.Color.DarkCyan;
            this.VideocardName.PlaceholderText = "";
            this.VideocardName.SelectedText = "";
            this.VideocardName.Size = new System.Drawing.Size(253, 29);
            this.VideocardName.Style = Guna.UI2.WinForms.Enums.TextBoxStyle.Material;
            this.VideocardName.TabIndex = 5;
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Font = new System.Drawing.Font("Kreadon Demi", 15.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.label3.Location = new System.Drawing.Point(11, 86);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(170, 23);
            this.label3.TabIndex = 4;
            this.label3.Text = "VideoCard Name";
            // 
            // RAM
            // 
            this.RAM.Animated = true;
            this.RAM.Cursor = System.Windows.Forms.Cursors.IBeam;
            this.RAM.DefaultText = "";
            this.RAM.DisabledState.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(208)))), ((int)(((byte)(208)))), ((int)(((byte)(208)))));
            this.RAM.DisabledState.FillColor = System.Drawing.Color.FromArgb(((int)(((byte)(226)))), ((int)(((byte)(226)))), ((int)(((byte)(226)))));
            this.RAM.DisabledState.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(138)))), ((int)(((byte)(138)))), ((int)(((byte)(138)))));
            this.RAM.DisabledState.PlaceholderForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(138)))), ((int)(((byte)(138)))), ((int)(((byte)(138)))));
            this.RAM.FocusedState.BorderColor = System.Drawing.Color.Teal;
            this.RAM.Font = new System.Drawing.Font("Kreadon Demi", 15.75F, System.Drawing.FontStyle.Bold);
            this.RAM.ForeColor = System.Drawing.Color.Black;
            this.RAM.HoverState.BorderColor = System.Drawing.Color.Teal;
            this.RAM.Location = new System.Drawing.Point(14, 148);
            this.RAM.Margin = new System.Windows.Forms.Padding(5, 5, 5, 5);
            this.RAM.Name = "RAM";
            this.RAM.PlaceholderForeColor = System.Drawing.Color.DarkCyan;
            this.RAM.PlaceholderText = "RAM";
            this.RAM.SelectedText = "";
            this.RAM.Size = new System.Drawing.Size(75, 29);
            this.RAM.Style = Guna.UI2.WinForms.Enums.TextBoxStyle.Material;
            this.RAM.TabIndex = 6;
            // 
            // ProcessorSpeed
            // 
            this.ProcessorSpeed.Animated = true;
            this.ProcessorSpeed.Cursor = System.Windows.Forms.Cursors.IBeam;
            this.ProcessorSpeed.DefaultText = "";
            this.ProcessorSpeed.DisabledState.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(208)))), ((int)(((byte)(208)))), ((int)(((byte)(208)))));
            this.ProcessorSpeed.DisabledState.FillColor = System.Drawing.Color.FromArgb(((int)(((byte)(226)))), ((int)(((byte)(226)))), ((int)(((byte)(226)))));
            this.ProcessorSpeed.DisabledState.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(138)))), ((int)(((byte)(138)))), ((int)(((byte)(138)))));
            this.ProcessorSpeed.DisabledState.PlaceholderForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(138)))), ((int)(((byte)(138)))), ((int)(((byte)(138)))));
            this.ProcessorSpeed.FocusedState.BorderColor = System.Drawing.Color.Teal;
            this.ProcessorSpeed.Font = new System.Drawing.Font("Kreadon Demi", 15.75F, System.Drawing.FontStyle.Bold);
            this.ProcessorSpeed.ForeColor = System.Drawing.Color.Black;
            this.ProcessorSpeed.HoverState.BorderColor = System.Drawing.Color.Teal;
            this.ProcessorSpeed.Location = new System.Drawing.Point(99, 148);
            this.ProcessorSpeed.Margin = new System.Windows.Forms.Padding(5, 5, 5, 5);
            this.ProcessorSpeed.Name = "ProcessorSpeed";
            this.ProcessorSpeed.PlaceholderForeColor = System.Drawing.Color.DarkCyan;
            this.ProcessorSpeed.PlaceholderText = "CPU Hz";
            this.ProcessorSpeed.SelectedText = "";
            this.ProcessorSpeed.Size = new System.Drawing.Size(109, 29);
            this.ProcessorSpeed.Style = Guna.UI2.WinForms.Enums.TextBoxStyle.Material;
            this.ProcessorSpeed.TabIndex = 7;
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.Font = new System.Drawing.Font("Kreadon Demi", 15.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.label4.Location = new System.Drawing.Point(14, 120);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(71, 23);
            this.label4.TabIndex = 8;
            this.label4.Text = "Other:";
            // 
            // guna2Button1
            // 
            this.guna2Button1.BorderRadius = 4;
            this.guna2Button1.BorderThickness = 10;
            this.guna2Button1.DisabledState.BorderColor = System.Drawing.Color.DarkGray;
            this.guna2Button1.DisabledState.CustomBorderColor = System.Drawing.Color.DarkGray;
            this.guna2Button1.DisabledState.FillColor = System.Drawing.Color.FromArgb(((int)(((byte)(169)))), ((int)(((byte)(169)))), ((int)(((byte)(169)))));
            this.guna2Button1.DisabledState.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(141)))), ((int)(((byte)(141)))), ((int)(((byte)(141)))));
            this.guna2Button1.FillColor = System.Drawing.Color.Black;
            this.guna2Button1.Font = new System.Drawing.Font("Kreadon Demi", 15.75F, System.Drawing.FontStyle.Bold);
            this.guna2Button1.ForeColor = System.Drawing.Color.White;
            this.guna2Button1.Location = new System.Drawing.Point(300, 234);
            this.guna2Button1.Name = "guna2Button1";
            this.guna2Button1.Size = new System.Drawing.Size(150, 35);
            this.guna2Button1.TabIndex = 9;
            this.guna2Button1.Text = "Save";
            this.guna2Button1.Click += new System.EventHandler(this.guna2Button1_Click);
            // 
            // Form1
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.Color.White;
            this.ClientSize = new System.Drawing.Size(473, 288);
            this.Controls.Add(this.guna2Button1);
            this.Controls.Add(this.label4);
            this.Controls.Add(this.ProcessorSpeed);
            this.Controls.Add(this.RAM);
            this.Controls.Add(this.VideocardName);
            this.Controls.Add(this.label3);
            this.Controls.Add(this.guna2PictureBox1);
            this.Controls.Add(this.ProcessorName);
            this.Controls.Add(this.label2);
            this.Controls.Add(this.label1);
            this.FormBorderStyle = System.Windows.Forms.FormBorderStyle.None;
            this.Name = "Form1";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "EditYourDevice";
            ((System.ComponentModel.ISupportInitialize)(this.guna2PictureBox1)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Label label1;
        private Guna.UI2.WinForms.Guna2BorderlessForm guna2BorderlessForm1;
        private System.Windows.Forms.Label label2;
        private Guna.UI2.WinForms.Guna2TextBox ProcessorName;
        private Guna.UI2.WinForms.Guna2PictureBox guna2PictureBox1;
        private Guna.UI2.WinForms.Guna2TextBox VideocardName;
        private System.Windows.Forms.Label label3;
        private Guna.UI2.WinForms.Guna2TextBox ProcessorSpeed;
        private Guna.UI2.WinForms.Guna2TextBox RAM;
        private System.Windows.Forms.Label label4;
        private Guna.UI2.WinForms.Guna2Button guna2Button1;
    }
}

