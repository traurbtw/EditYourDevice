﻿using System;
using System.Diagnostics;
using System.Runtime.InteropServices;
using System.Windows.Forms;
using Microsoft.Win32;

namespace EditYourDevice
{
    public partial class Form1 : Form
    {
       
        [DllImport("user32.dll", SetLastError = true, CharSet = CharSet.Auto)]
        public static extern IntPtr SendMessageTimeout(
            IntPtr hWnd, uint Msg, UIntPtr wParam, string lParam,
            uint fuFlags, uint uTimeout, out UIntPtr lpdwResult);

        private const uint WM_SETTINGCHANGE = 0x001A;
        private const uint SMTO_ABORTIFHUNG = 0x0002;

        public Form1()
        {
            InitializeComponent();
        }

        private void guna2Button1_Click(object sender, EventArgs e)
        {
            try
            {
                // Изменение параметров в реестре
                SetRegistryValue(@"HARDWARE\DESCRIPTION\System\CentralProcessor\0", "ProcessorNameString", ProcessorName.Text);
                SetRegistryValue(@"SYSTEM\CurrentControlSet\Control\Class\{4d36e968-e325-11ce-bfc1-08002be10318}\0000", "DriverDesc", VideocardName.Text);
                SetRegistryValue(@"HARDWARE\DESCRIPTION\System\CentralProcessor\0", "Identifier", RAM.Text);
                SetRegistryValue(@"HARDWARE\DESCRIPTION\System\CentralProcessor\0", "~MHz", ProcessorSpeed.Text);

                // Попытка обновить систему без перезагрузки
                NotifySystemChanges();
                RestartExplorer();
                RestartTaskManager();

                MessageBox.Show("Изменения применены! Откройте Диспетчер задач снова для проверки.");
            }
            catch (Exception ex)
            {
                MessageBox.Show($"Ошибка: {ex.Message}");
            }
        }

        private void SetRegistryValue(string subKey, string valueName, string value)
        {
            try
            {
                using (RegistryKey key = Registry.LocalMachine.OpenSubKey(subKey, true))
                {
                    if (key != null)
                    {
                        key.SetValue(valueName, value);
                    }
                    else
                    {
                        MessageBox.Show($"Ключ реестра не найден: {subKey}");
                    }
                }
            }
            catch (UnauthorizedAccessException)
            {
                MessageBox.Show("Требуются права администратора!");
            }
            catch (Exception ex)
            {
                MessageBox.Show($"Ошибка реестра: {ex.Message}");
            }
        }

        private void NotifySystemChanges()
        {
            try
            {
                // Отправка системного сообщения о изменении параметров
                SendMessageTimeout(
                    (IntPtr)0xFFFF, // HWND_BROADCAST
                    WM_SETTINGCHANGE,
                    UIntPtr.Zero,
                    "Environment",
                    SMTO_ABORTIFHUNG,
                    1000,
                    out UIntPtr _);
            }
            catch (Exception ex)
            {
                Debug.WriteLine($"Ошибка уведомления системы: {ex.Message}");
            }
        }

        private void RestartExplorer()
        {
            try
            {
                foreach (Process process in Process.GetProcessesByName("explorer"))
                {
                    process.Kill();
                }
                Process.Start("explorer.exe");
            }
            catch (Exception ex)
            {
                Debug.WriteLine($"Ошибка перезапуска проводника: {ex.Message}");
            }
        }

        private void RestartTaskManager()
        {
            try
            {
                foreach (Process process in Process.GetProcessesByName("Taskmgr"))
                {
                    process.Kill();
                }
            }
            catch (Exception ex)
            {
                Debug.WriteLine($"Ошибка закрытия диспетчера задач: {ex.Message}");
            }
        }

        private void guna2PictureBox1_Click(object sender, EventArgs e)
        {
            try
            {
                Process.Start(new ProcessStartInfo("https://github.com/traurbtw") { UseShellExecute = true });
            }
            catch (Exception ex)
            {
                MessageBox.Show($"Ошибка: {ex.Message}");
            }
        }
    }
}